package com.cts.entity.service;

import java.util.List;
import java.util.Optional;

import com.cts.entity.ShoppingCartEntity;

public interface IcartService {

	List<ShoppingCartEntity> getAllCart();

	Optional<ShoppingCartEntity> getPersonById(int pid);

	ShoppingCartEntity addCart(ShoppingCartEntity cItem);

	void deleteById(Integer bId);

	void deleteAllCart();

	String addCart(int bid, ShoppingCartEntity cItem);

	String updateCart(int cid, ShoppingCartEntity scart1);
	
	

	

	
	
	
	
	

	

}
