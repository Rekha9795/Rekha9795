package com.cts.entity.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.entity.BuyerEntity;
import com.cts.entity.ShoppingCartEntity;
import com.cts.entity.dao.BuyerDao;
import com.cts.entity.dao.CartDao;
@Service
public class CartService implements IcartService {
	@Autowired
	private BuyerDao bdao;
	
	@Autowired
	private CartDao cdao;
	
	@Override
	public String addCart(int bid, ShoppingCartEntity cItem) {
		BuyerEntity br=bdao.getOne(bid);
		cItem.setBuyer(br);  
		System.out.println(cItem);
		 cdao.save(cItem);
		 return "Return buyer";
	}

	
	
	
	
	@Override
public List<ShoppingCartEntity> getAllCart() {
		
		return cdao.findAll();
	}
	
	
	@Override
	public Optional<ShoppingCartEntity> getPersonById(int id) {
		
		return cdao.findById(id);
	}
	
	
	/*
	 * @Override public ShoppingCartEntity addCart(ShoppingCartEntity cItem) {
	 * 
	 * return cdao.save(cItem);
	 * 
	 * 
	 * }
	 */
	@Override
	public void deleteById(Integer bId) {
		Optional<ShoppingCartEntity> buyer = cdao.findById(bId);
		
		if(buyer.isPresent()) {
			cdao.deleteById(bId);
		}
		
	}

	
	
	@Override
	public void deleteAllCart() {
		cdao.deleteAll();
		
	}


	@Override
	public ShoppingCartEntity addCart(ShoppingCartEntity cItem) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public String updateCart(int cid, ShoppingCartEntity scart1) 
	{
		
		ShoppingCartEntity update=cdao.getOne(cid);
		
		int quantity=scart1.getQuantity();
		float tprice=scart1.getPrice();
		String discription=scart1.getDescription();
		update.setQuantity(quantity);
		update.setPrice(tprice);
		update.setDescription(discription);
		System.out.println(update);
		cdao.save(update);
		return "\"Cart item updated\"";
	}

	


	

	

	
	
	

}
