package com.cts.entity.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.entity.BuyerEntity;
import com.cts.entity.ShoppingCartEntity;
import com.cts.entity.service.IcartService;


@RestController
public class CartController {
		

		@Autowired
		private IcartService icart;
	
	@GetMapping("/getAll/CartItem")
	public List<ShoppingCartEntity> getAll(){
		
		return icart.getAllCart();
	}
	
	@RequestMapping("getById/buyerId/{eid}")
	public ShoppingCartEntity getbyId(@PathVariable("eid") int pid) {
		
		Optional<ShoppingCartEntity> p=icart.getPersonById(pid);
		ShoppingCartEntity pObj=null;
		if(p.isPresent()){
		 pObj=p.get();	
		}		
		return pObj;
	}
	
	@PostMapping("/addToCart/BuyerId/{bid}")
			public String addCart(@PathVariable("bid")int bid, @RequestBody ShoppingCartEntity cItem) {
		return icart.addCart(bid,cItem);
	}
	
	
	@DeleteMapping("deleteById/{bid}")
	public void deleteById(@PathVariable("bid") Integer bId) {
		
		icart.deleteById(bId);
		
	}
	

	@DeleteMapping("/deleteAllCart")
	public void deleteAllCart() {
		
		icart.deleteAllCart();
		
	}
	
	
	@PostMapping("/updatecart/{cid}")
	public String updateCart(@PathVariable("cid") int cid,@RequestBody ShoppingCartEntity scart1)
	{
		return icart.updateCart(cid,scart1);
	}
	
	
	
	
}
