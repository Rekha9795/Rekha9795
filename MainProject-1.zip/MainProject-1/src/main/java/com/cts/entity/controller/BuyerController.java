package com.cts.entity.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.entity.BuyerEntity;
import com.cts.entity.service.BuyerService;
import com.cts.entity.service.IBuyerService;

@RestController
public class BuyerController {
	@Autowired
	private IBuyerService buyerser;
	
	@GetMapping("/getAll")
	public List<BuyerEntity> getAll(){
		
		return buyerser.getAllBuyers();
	}
	
	@RequestMapping(value="/addBuyer", method= RequestMethod.POST, produces="application/json")
	public BuyerEntity addBuyer(@RequestBody BuyerEntity buyer) {
		
		return buyerser.add(buyer);
	}

}
