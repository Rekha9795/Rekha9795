package com.cts.entity;

public class TransactionEntity {

}
