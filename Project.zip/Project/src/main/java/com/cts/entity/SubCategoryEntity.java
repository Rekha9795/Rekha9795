package com.cts.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class SubCategoryEntity {
	@Id
	private int subcategoryId;
	private String subcategoryName;
	private int categoryId;
	private String briefDetails;
	
	
	public SubCategoryEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getSubcategoryId() {
		return subcategoryId;
	}
	public void setSubcategoryId(int subcategoryId) {
		this.subcategoryId = subcategoryId;
	}
	public String getSubcategoryName() {
		return subcategoryName;
	}
	public void setSubcategoryName(String subcategoryName) {
		this.subcategoryName = subcategoryName;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public String getBriefDetails() {
		return briefDetails;
	}
	public void setBriefDetails(String briefDetails) {
		this.briefDetails = briefDetails;
	}
	@Override
	public String toString() {
		return "SubCategoryEntity [subcategoryId=" + subcategoryId + ", subcategoryName=" + subcategoryName
				+ ", categoryId=" + categoryId + ", briefDetails=" + briefDetails + "]";
	}


}
