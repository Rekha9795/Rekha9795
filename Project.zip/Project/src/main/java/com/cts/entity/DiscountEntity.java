package com.cts.entity;

public class DiscountEntity {

}
