package com.cts.entity;

public class ShoppingCartEntity {

}
