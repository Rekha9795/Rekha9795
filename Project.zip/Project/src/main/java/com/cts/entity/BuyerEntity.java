package com.cts.entity;
import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class BuyerEntity implements Serializable {
	@Id
private int buyerId;
private String userName;
private String password;
private String email;
private long mobileNumber;

public BuyerEntity() {
	
}

public int getBuyerId() {
	return buyerId;
}
public void setBuyerId(int buyerId) {
	this.buyerId = buyerId;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public long getMobileNumber() {
	return mobileNumber;
}
public void setMobileNumber(long mobileNumber) {
	this.mobileNumber = mobileNumber;
}
public BuyerEntity(int buyerId, String userName, String password, String email, long mobileNumber) {
	super();
	this.buyerId = buyerId;
	this.userName = userName;
	this.password = password;
	this.email = email;
	this.mobileNumber = mobileNumber;
}
@Override
public String toString() {
	return "BuyerEntity [buyerId=" + buyerId + ", userName=" + userName + ", password=" + password + ", email=" + email
			+ ", mobileNumber=" + mobileNumber + "]";
}



	

}
